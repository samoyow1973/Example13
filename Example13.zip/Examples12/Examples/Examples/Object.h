#pragma once
#ifndef OBJECT_H
#define OBJECT_H
#include "D3D.h"
#include <fbxsdk.h> 
VOID CreateSphere(UINT);
XMMATRIX FbxToMatrix(FbxAMatrix*);
XMMATRIX GetNodeMatrix(FbxNode*);
VOID ImportFBX(LPCSTR);
#endif